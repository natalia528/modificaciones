<?php
    $acudiente = $_POST["acudiente"];
    $estudiante = $_POST["estudiante"];
    $curso = $_POST["curso"];
    $jornada = $_POST["jornada"];
    $correo = $_POST["correo"];
    $mensaje = $_POST["mensaje"];
    $adjunto = $_POST["adjunto"];
    $fecha = time();
    $fechaFormateada = date("j/n/Y", $fecha);

    $correoFrom = "correo@servidor.com"; //El correo debe salir de un servidor de correo
    $correoDestino = "correo@mail.com"; //EL correo a donde llegará la info


    $headers =
	'From: ' . $correoFrom . "\r\n". 
	'Reply-To: ' . $correoDestino. "\r\n" . 
	'X-Mailer: PHP/' . phpversion() .
	'MIME-Version: 1.0\r\n'.
	'Content-type: text/html; charset=UTF-8\r\n';

    //Formateo el asunto del correo
    $asunto = "Contacto Colegio Montessori - Página Web";
    //Formateo el cuerpo del correo
    $cuerpo = "Enviado por: " . $acudiente . ", a las " . $fechaFormateada . "";
    $cuerpo .= "Estudiante: " . $estudiante . ", del curso " . $curso . " y jornada " . $jornada . "";
    $cuerpo .= "E-mail: " . $correo . "";
    $cuerpo .= "Comentario: " . $mensaje . "";
    $cuerpo .= "Archivos adjuntos: " . $adjunto . "";

    mail( $correoDestino, $asunto, $cuerpo, $headers);
    echo'<script type="text/javascript">alert("El mensaje se ha enviado correctamente, nos contactaremos pronto con usted");
        window.location.href="../contactenos.html";</script>';
    
?>