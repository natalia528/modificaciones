<?php
    //Mediante el método connect
    //crea un objeto conexion
$conexion = new mysqli();
    //conecta al servidor
$conexion->connect('localhost', 'root', '', 'dbcolegio');

if ($conexion->connect_errno != null) {
        //Muestra un error si la conexion falla
    echo "Error número $conexion->connect_errno conectando a la base de datos.<br>Mensaje: $db->connect_error.";
    exit();
}
if ($_POST){
        //el if verifica que los campos no esten vacios

        //Guarda los valores de los input en variables
    $usuario = $_POST["usuario"];
    $contrasena = $_POST["contrasena"];

            //se guarda la sentencia sql en una variable
    $consulta = "SELECT * FROM Usuarios WHERE Usuario = '$usuario' AND Password = '$contrasena'";

            //se realiza la consulta
    $query = $conexion->query($consulta);


            //en el if se verifica que hayan datos, y si no los hay muestra un mensaje
    if ($query->num_rows > 0) {
                //echo "El usuario existe";
                //header ("Location: ../estudiante.html");
                //exit();
      while($row = $query->fetch_assoc()){
         $idusuario = $row['idUsuario'];
         $usuario = $row['Usuario'];
         $password = $row['Password']; 
         $idpersonas = $row['fk_idPersonas'];
         $rol = $row['RolSistema_idRolSistema'];

                       //echo $rol;

         if($rol == 1 || $rol == 2){?>
            <!DOCTYPE html>
            <html>

            <head>
                <!-- Required meta tags -->
                <meta charset="utf-8">
                <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
                <!-- Bootstrap CSS -->
                <link href="../css/inicio.css" rel="StyleSheet" type="text/css">
                <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
                integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" rel="stylesheet">
                <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
                integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
                <link href="../css/inicio.css" rel="StyleSheet" type="text/css">
                <link href="../css/sesion.css" rel="StyleSheet" type="text/css">


                <title>
                    Sesion - Colegio Montessoriano
                </title>
            </head>

            <body>
                <nav class="navbar navbar-expand-lg navbar-light bg-primary shadow fixed-top nav-pills">
                    <div class="container">
                        <div class="izquierda">
                            <a class="navbar-brand" href="../index.html">
                                <img class="logo" src="../img/escudo.jpg" title="logo">
                            </img>
                        </a>
                    </div>
                    <div class="navegador justify-content-center">
                        <button aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"
                        class="navbar-toggler" data-target="#navbarResponsive" data-toggle="collapse" type="button">
                        <span class="navbar-toggler-icon">
                        </span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarResponsive">
                        <ul class="navbar-nav justify-content-center">
                            <li class="nav-item active">
                                <a class="nav-link" href="../index.html">
                                    Inicio
                                </a>

                                <li class="nav-item">
                                    <a class="nav-link" href="../ingresar.html">
                                        Ingresar
                                    </a>

                                    <li class="nav-item">
                                        <a class="nav-link" href="../colegio.html">
                                            Acerca de
                                        </a>

                                        <li class="nav-item">
                                            <a class="nav-link" href="../contactenos.html">
                                                Contáctanos
                                            </a>
                                        </div>
                                    </div>
                                    <div class="derecha ">
                                        <div class="navbar-brand justify-content-center">
                                            <!--<a  href="../index.html">
                                                <img class="logo" src="../img/Logo.png" title="logo">
                                                </img>
                                            </a>-->
                                            <button class="btn btn-light" onclick="location.href='../ingresar.html'">Cerrar sesión</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </nav>
                            <section class="seccion">
                                <div class="container h-100">
                                    <div class="row h-100 justify-content-center align-items-center ">
                                        <div class="col-6 text-center">
                                            <div class="seccion">
                                                <div class="titulo">
                                                    <h1>Colegio Montessori</h1>
                                                    <h2><?php echo 'Bienvenido ', $usuario?></h2>
                                                </div>
                                            </div>
                                            <table class ="table">
                                                <thead class="thead-primary">
                                                    <tr class="tabla">
                                                        <th class="col-2"><strong>ID</strong></th>
                                                        <th class="col-2"><strong>Fecha</strong></th>
                                                        <th class="col-2"><strong>Hora</strong></th>
                                                        <th class="col-4"><strong>Descripcion</strong></th>
                                                        <th class="col-2"><strong>ID Personal</strong></th>
                                                        <!--<td><strong>Hora</strong></td>-->
                                                    </tr>
                                                </thead>
                                                <tbody class="datos">
                                                    <?php 
                                                    if($conexion){
                                                                //SELECT * FROM `Asistencia` WHERE `fk_idPersonas` LIKE '1004'
                                                        $consulta = "SELECT * FROM Asistencia WHERE fk_idPersonas LIKE '$idpersonas';";
                                                        $query = $conexion->query($consulta);
                                                        if($query){
                                                            while($row = $query->fetch_assoc()){
                                                                $idAsist = $row['idAsistencia'];
                                                                $fecha = $row['Fecha'];
                                                                $hora = $row['Hora']; 
                                                                $descripcion = $row['Descripcion'];
                                                                $documento = $row['fk_idPersonas'];?>
                                                                <tr>
                                                                    <td><?php echo  $row['idAsistencia']; ?></td>
                                                                    <td><?php echo  $row['Fecha'];?></td>
                                                                    <td><?php echo  $row['Hora'];?></td>
                                                                    <td><?php echo  $row['Descripcion'];?></td>
                                                                    <td><?php echo  $row['fk_idPersonas'];?></td>
                                                                </tr>
                                                                <?php


                                                            }
                                                        }

                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>      
                                    </div>
                                </div>
                            </section>
                        </body>
                        </html>
                        <?php
                    }
                    elseif($rol == 3){
                        echo'<script type="text/javascript">window.location.href="./documentos.php";</script>';
                    }
                }
                $conexion->close();
            } else {
                echo'<script type="text/javascript">alert("El usuario o contraseña estan incorrectos");
                window.location.href="../ingresar.html";</script>';
                $conexion->close();
            }
        }
        else {
            echo "<script>alert('Rellene los campos vacios');
            window.location.href='../ingresar.html';</script>";

            $conexion->close();
        }

        ?>
