<?php
    //Mediante el método connect
    //crea un objeto conexion
    $conexion = new mysqli();
    //conecta al servidor
    $conexion->connect('localhost', 'root', '', 'dbcolegio');

    if ($conexion->connect_errno != null) {
        //Muestra un error si la conexion falla
        echo "Error número $conexion->connect_errno conectando a la base de datos.<br>Mensaje: $db->connect_error.";
        exit();
    }

    if (isset($_POST["usuario"], $_POST["contrasena"], $_POST["nombre"], $_POST["apellido"],$_POST["documento"],$_POST["curso"], $_POST["telefono"],$_POST["jornada"], $_POST["direccion"], $_POST["ciudad"], $_POST["genero"],$_POST["tipo-documento"],$_POST["tipo-usuario"]) and $_POST["contrasena"]!="" and $_POST["nombre"] !="" and $_POST["apellido"]!="" and $_POST["curso"] !="" and $_POST["telefono"]!="" and $_POST["jornada"] !="" and $_POST["direccion"]!=""  and $_POST["ciudad"] !="" and $_POST["genero"]!="" and $_POST["tipo-documento"]!="" and $_POST["tipo-usuario"]!="" and $_POST["documento"]!="" and $_POST["usuario"]!=""){
        //el if verifica que los campos no esten vacios

        //Guarda los valores de los input en variables
            //$id = $_POST["id"];
            $usuario = $_POST["usuario"];
            $contrasena = $_POST["contrasena"];
            $nombre = $_POST["nombre"];
            $apellido = $_POST["apellido"];
            $curso = $_POST["curso"];
            $documento = $_POST["documento"];
            $telefono = $_POST["telefono"];
            $jornada = $_POST["jornada"];
            $direccion = $_POST["direccion"];
            $ciudad = $_POST["ciudad"];
            $genero = $_POST["genero"];
            $tipo_documento = $_POST["tipo-documento"];
            $tipo_usuario = $_POST["tipo-usuario"];


            //se guarda la sentencia sql en una variable
            $consulta = "
            
            INSERT INTO Personas VALUES (
                '$documento', '$nombre', '$apellido', '$documento', 
                '$telefono', '$jornada', '$curso', '$direccion', '$tipo_documento', 
                '$ciudad', '$tipo_usuario', '$genero');";
            $consulta2 = "
            INSERT INTO Usuarios VALUES (
                '$documento', '$usuario', '$contrasena', '$documento', '$tipo_usuario');
            ";

            //echo $consulta;

            $query = $conexion->multi_query($consulta);
            
            //echo $consulta2;

            $query2 = $conexion->multi_query($consulta2);
            //en el if se verifica que hayan datos, y si no los hay muestra un mensaje
            if ($query ===TRUE && $query2 ==TRUE) {

                //echo "Se ha registrado exitosamente";//echo "Falló la multiconsulta: (" . $conexion->errno . ") " . $conexion->error;
                echo'<script type="text/javascript">alert("Se ha registrado exitosamente");
                window.location.href="../ingresar.html";</script>';
            }
            else{
                echo "Falló la multiconsulta: (" . $conexion->errno . ") " . $conexion->error;
            }
            
            
            /*
            if ($query = $conexion->multi_query($consulta)) {
                echo "El usuario se ha registrado correctamente";
                $conexion->close();
             */   
            }
    else {
        echo'<script type="text/javascript">alert("Rellene los campos vacios");
                window.location.href="../ingresar.html";</script>';
            $conexion->close();
    }

?>
