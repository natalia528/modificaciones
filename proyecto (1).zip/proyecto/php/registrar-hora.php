<?php
    //Mediante el método connect
    //crea un objeto conexion
    $conexion = new mysqli();
    //conecta al servidor
    $conexion->connect('localhost', 'root', '', 'dbcolegio');

    if ($conexion->connect_errno != null) {
        //Muestra un error si la conexion falla
        echo "Error número $conexion->connect_errno conectando a la base de datos.<br>Mensaje: $db->connect_error.";
        exit();
    }

    if(isset($_POST["fecha"], $_POST["hora"], $_POST["observacion"], $_POST["documento"]) and $_POST["fecha"] !="" and $_POST["hora"] !="" and $_POST["observacion"] !="" and $_POST["documento"] !=""){
        //el if verifica que los campos no esten vacios

        //Guarda los valores de los input en variables
            //$id = $_POST["id"];
            $fecha = $_POST["fecha"];
            $hora = $_POST["hora"];
            $observacion = $_POST["observacion"];
            $documento = $_POST["documento"];

        
            //se guarda la sentencia sql en una variable
            $consulta = "INSERT INTO Asistencia (idAsistencia, Fecha, Hora, Descripcion, fk_idPersonas) VALUES (NULL, '$fecha', '$hora', '$observacion', '$documento')";
            
            //en el if se verifica que hayan datos, y si no los hay muestra un mensaje
            if ($conexion->query($consulta)) {
                echo'<script type="text/javascript">alert("La hora se ha registrado correctamente");
                window.location.href="./ingresar.php";</script>';
                $conexion->close();
            } else {
                echo'<script type="text/javascript">alert("Ha habido un error, verifique los campos");
                window.location.href="./ingresar.php";</script>';
                $conexion->close();
            }
    }
            
    else {
        echo'<script type="text/javascript">alert("Rellene los campos vacios");
                window.location.href="./ingresar.php";</script>';
            $conexion->close();
    }
    

?>
