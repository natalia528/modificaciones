<?php
    //Mediante el método connect
    //crea un objeto conexion
$conexion = new mysqli();
    //conecta al servidor
$conexion->connect('localhost', 'root', '', 'dbcolegio');

if ($conexion->connect_errno != null) {
        //Muestra un error si la conexion falla
    echo "Error número $conexion->connect_errno conectando a la base de datos.<br>Mensaje: $db->connect_error.";
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1, shrink-to-fit=no" name="viewport">
    <!-- Bootstrap CSS -->
    <link href="../css/inicio.css" rel="StyleSheet" type="text/css">
    <link crossorigin="anonymous" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css"
    integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <link href="../css/inicio.css" rel="StyleSheet" type="text/css">
    <link href="../css/sesion.css" rel="StyleSheet" type="text/css">


    <title>
        Sesion - Colegio Montessoriano
    </title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary shadow fixed-top nav-pills">
        <div class="container">
            <div class="izquierda">
                <a class="navbar-brand" href="../index.html">
                    <img class="logo" src="../img/escudo.jpg" title="logo">
                </img>
            </a>
        </div>
        <div class="navegador justify-content-center">
            <button aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"
            class="navbar-toggler" data-target="#navbarResponsive" data-toggle="collapse" type="button">
            <span class="navbar-toggler-icon">
            </span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav justify-content-center">
                <li class="nav-item active">
                    <a class="nav-link" href="../index.html">
                        Inicio
                    </a>

                    <li class="nav-item">
                        <a class="nav-link" href="../ingresar.html">
                            Ingresar
                        </a>

                        <li class="nav-item">
                            <a class="nav-link" href="../colegio.html">
                                Acerca de
                            </a>

                            <li class="nav-item">
                                <a class="nav-link" href="../contactenos.html">
                                    Contáctanos
                                </a>
                            </div>
                        </div>
                        <div class="derecha ">
                            <div class="navbar-brand justify-content-center">
                                            <!--<a  href="../index.html">
                                                <img class="logo" src="../img/Logo.png" title="logo">
                                                </img>
                                            </a>-->
                                            <button class="btn btn-light" onclick="location.href='../ingresar.html'">Cerrar sesión</button>
                                        </div>                                        
                                    </div>
                                </div>
                            </nav>
                            <section class="seccion">
                                <div class="container h-100">
                                    <div class="row h-100 justify-content-center align-items-center ">
                                        <div class="col-6 text-center">
                                            <div class="seccion">
                                                <div class="titulo">
                                                    <h1>Colegio Montessori</h1>
                                                    <h2><?php echo 'Bienvenido ', $usuario?></h2>
                                                </div>
                                            </div>
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-12">
                                                        <?php
                                                        if($conexion){
                                                            $documento = $_POST["documento"];?>

                                                            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post"><div class="form-group">
                                                                <label>Documento</label>
                                                                <input type="text" id="documento" name="documento" class="form-control"/>
                                                            </div>
                                                            <div class="form-group">
                                                                <button type="submit" class="btn btn-primary"> Buscar</button>
                                                            </div>


                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            <table class ="table">
                                                <thead class="thead-primary">
                                                    <tr class="tabla">
                                                        <th class="col-2"><strong>ID</strong></th>
                                                        <th class="col-2"><strong>Fecha</strong></th>
                                                        <th class="col-2"><strong>Hora</strong></th>
                                                        <th class="col-4"><strong>Descripcion</strong></th>
                                                        <th class="col-2"><strong>ID Personal</strong></th>
                                                        <!--<td><strong>Hora</strong></td>-->
                                                    </tr>
                                                </thead>
                                                <tbody class="datos">
                                                    <?php 
                                                        //SELECT * FROM `Asistencia` WHERE `fk_idPersonas` LIKE '1004'
                                                    $consulta2 = "SELECT * FROM Asistencia WHERE fk_idPersonas LIKE '$documento';";
                                                    $query2 = $conexion->query($consulta2);
                                                    if($query2){
                                                        while($row2 = $query2->fetch_assoc()){
                                                            $idAsist = $row2['idAsistencia'];
                                                            $fecha = $row2['Fecha'];
                                                            $hora = $row2['Hora']; 
                                                            $descripcion = $row2['Descripcion'];
                                                            $documento = $row2['fk_idPersonas'];?>
                                                            <tr>
                                                                <td><?php echo  $row2['idAsistencia']; ?></td>
                                                                <td><?php echo  $row2['Fecha'];?></td>
                                                                <td><?php echo  $row2['Hora'];?></td>
                                                                <td><?php echo  $row2['Descripcion'];?></td>
                                                                <td><?php echo  $row2['fk_idPersonas'];?></td>
                                                            </tr>
                                                            <?php


                                                        }
                                                    }

                                                }

                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <section class="seccion-2">
                            <div class="container">
                                <div class="row align-items-center justify-content-center">
                                    <div class="col-6 text-center">
                                        <h2>Ingresar Hora</h2>
                                        <form action="registrar-hora.php" method="POST">
                                            <div class="form-group">
                                                <label for="fecha">Fecha</label>
                                                <input type="text" name="fecha" value="" id="fecha" class="form-control form-control-sm">
                                            </div>
                                            <div class="form-group">
                                                <label for="hora">Hora</label>
                                                <input type="text" name="hora" value="" id="hora" class="form-control form-control-sm">
                                            </div>
                                            <div class="form-group">
                                                <label for="observacion">Observacion</label>
                                                <input type="text" name="observacion" value="" id="observacion" class="form-control form-control-sm">
                                            </div>
                                            <div class="form-group">
                                                <label for="documento">Documento</label>
                                                <input type="text" name="documento" value="" id="documento" class="form-control form-control-sm"> 
                                            </div>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-primary"> Ingresar</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <img src="img/registro.png" />
                        </div>
                    </body>