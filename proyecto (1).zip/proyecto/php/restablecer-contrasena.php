<?php
    //Mediante el método connect
    //crea un objeto conexion
    $conexion = new mysqli();
    //conecta al servidor
    $conexion->connect('localhost', 'root', '', 'dbcolegio');

    if ($conexion->connect_errno != null) {
        //Muestra un error si la conexion falla
        echo "Error número $conexion->connect_errno conectando a la base de datos.<br>Mensaje: $db->connect_error.";
        exit();
    }
    if(isset($_POST["documento"], $_POST["correo"], $_POST["contrasena"]) and $_POST["documento"] !="" and $_POST["correo"] !="" and $_POST["contrasena"] !=""){
        $documento = $_POST["documento"];
        $correo = $_POST["correo"];
        $contrasena = $_POST["contrasena"];


        $hacia = $correo;
        $asunto = "Restablecer Contraseña - Colegio Montessori";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        
        $mensaje = "
        <html>
        <head>
        <title>Restablecimiento de contraseña</title>
        </head>
        <body>
        <h1>Tu contraseña se ha restablecido correctamente</h1>
        <p>La nueva contraseña es $contrasena</p>
        </body>
        </html>";

        $consulta = "UPDATE `Usuarios` SET `Password` = '$contrasena' WHERE `Usuarios`.`idUsuarios` = '$documento'";

        if ($conexion->query($consulta)) {
            mail($hacia, $asunto, $mensaje, $headers);
            echo'<script type="text/javascript">alert("La contraseña se ha cambiado correctamente");
            window.location.href="../ingresar.html";</script>';
            $conexion->close();

        } else {
            echo'<script type="text/javascript">alert("Ha habido un error, verifique los campos");
            window.location.href="../ingresar.html";</script>';
            $conexion->close();
        }
    }
?>