-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 28-06-2021 a las 04:15:39
-- Versión del servidor: 10.4.19-MariaDB
-- Versión de PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbcolegio`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Asistencia`
--

CREATE TABLE `Asistencia` (
  `idAsistencia` int(11) NOT NULL,
  `Fecha` varchar(15) NOT NULL,
  `Hora` varchar(15) NOT NULL,
  `Descripcion` varchar(500) NOT NULL,
  `fk_idPersonas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Asistencia`
--

INSERT INTO `Asistencia` (`idAsistencia`, `Fecha`, `Hora`, `Descripcion`, `fk_idPersonas`) VALUES
(1, '10/05/2015', '03:30', 'aa', 150),
(2, '10/05/2015', '03:45', 'aa', 200),
(3, '10/05/2016', '02:30', 'Cualquiera', 200);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Ciudad`
--

CREATE TABLE `Ciudad` (
  `idCiudad` int(11) NOT NULL,
  `Descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Ciudad`
--

INSERT INTO `Ciudad` (`idCiudad`, `Descripcion`) VALUES
(1, 'Bogotá'),
(2, 'Cali');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Genero`
--

CREATE TABLE `Genero` (
  `idGenero` int(11) NOT NULL,
  `Descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Genero`
--

INSERT INTO `Genero` (`idGenero`, `Descripcion`) VALUES
(1, 'M'),
(2, 'F');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Personas`
--

CREATE TABLE `Personas` (
  `idPersonas` int(11) NOT NULL,
  `Nombre` varchar(50) NOT NULL,
  `Apellido` varchar(50) NOT NULL,
  `Documento` varchar(11) NOT NULL,
  `Telefono` varchar(25) NOT NULL,
  `Jornada` varchar(20) NOT NULL,
  `Curso` varchar(20) NOT NULL,
  `Direccion` varchar(50) NOT NULL,
  `fk_idTipoDocumento` int(11) NOT NULL,
  `fk_idCiudad` int(11) NOT NULL,
  `fk_idTipoUsuario` int(11) NOT NULL,
  `fk_idGenero` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Personas`
--

INSERT INTO `Personas` (`idPersonas`, `Nombre`, `Apellido`, `Documento`, `Telefono`, `Jornada`, `Curso`, `Direccion`, `fk_idTipoDocumento`, `fk_idCiudad`, `fk_idTipoUsuario`, `fk_idGenero`) VALUES
(150, 'Juan', 'Perez', '150', '5203525', 'Tarde', '1002', 'Calle 5 # 3 20', 1, 1, 2, 1),
(200, 'Alex', 'Monroy', '200', '5203525', 'Tarde', '1002', 'Calle 5 # 3 20', 1, 1, 3, 1),
(1111, 'Juana', 'Fernandez', '1111', '3214', 'MaÃ±ana', '1102', 'Carrera 4 # 3 - 50', 1, 1, 1, 2),
(1023654, 'Juana', 'Reyes', '1023654', '123456', 'MaÃ±ana', '1001', 'Carrera 4 # 3 - 50', 1, 1, 1, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `RolSistema`
--

CREATE TABLE `RolSistema` (
  `idRolSistema` int(11) NOT NULL,
  `Tipo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `RolSistema`
--

INSERT INTO `RolSistema` (`idRolSistema`, `Tipo`) VALUES
(1, 'Estudiante'),
(2, 'Docente'),
(3, 'Administrativo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TipoDocumento`
--

CREATE TABLE `TipoDocumento` (
  `idTipoDocumento` int(11) NOT NULL,
  `Descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `TipoDocumento`
--

INSERT INTO `TipoDocumento` (`idTipoDocumento`, `Descripcion`) VALUES
(1, 'Tarjeta de Identidad'),
(2, 'Cédula de Ciudadanía');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `TipoUsuario`
--

CREATE TABLE `TipoUsuario` (
  `idTipoUsuario` int(11) NOT NULL,
  `Descripcion` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `TipoUsuario`
--

INSERT INTO `TipoUsuario` (`idTipoUsuario`, `Descripcion`) VALUES
(1, 'Estudiante'),
(2, 'Docente'),
(3, 'Coordinador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios`
--

CREATE TABLE `Usuarios` (
  `idUsuarios` int(11) NOT NULL,
  `Usuario` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `fk_idPersonas` int(11) NOT NULL,
  `RolSistema_idRolSistema` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Usuarios`
--

INSERT INTO `Usuarios` (`idUsuarios`, `Usuario`, `Password`, `fk_idPersonas`, `RolSistema_idRolSistema`) VALUES
(150, 'Docente', '1234', 150, 2),
(200, 'Administrativo', '1235', 200, 3),
(1111, 'Juana', '1234', 1111, 1),
(1023654, 'Juana', '1234', 1023654, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Asistencia`
--
ALTER TABLE `Asistencia`
  ADD PRIMARY KEY (`idAsistencia`,`fk_idPersonas`),
  ADD KEY `fk_Asistencia_Personas1` (`fk_idPersonas`);

--
-- Indices de la tabla `Ciudad`
--
ALTER TABLE `Ciudad`
  ADD PRIMARY KEY (`idCiudad`);

--
-- Indices de la tabla `Genero`
--
ALTER TABLE `Genero`
  ADD PRIMARY KEY (`idGenero`);

--
-- Indices de la tabla `Personas`
--
ALTER TABLE `Personas`
  ADD PRIMARY KEY (`idPersonas`,`fk_idTipoDocumento`,`fk_idCiudad`,`fk_idTipoUsuario`,`fk_idGenero`),
  ADD KEY `fk_TipoDocumento` (`fk_idTipoDocumento`),
  ADD KEY `fk_Ciudad1` (`fk_idCiudad`),
  ADD KEY `fk_TipoUsuario1` (`fk_idTipoUsuario`),
  ADD KEY `fk_Genero1` (`fk_idGenero`);

--
-- Indices de la tabla `RolSistema`
--
ALTER TABLE `RolSistema`
  ADD PRIMARY KEY (`idRolSistema`);

--
-- Indices de la tabla `TipoDocumento`
--
ALTER TABLE `TipoDocumento`
  ADD PRIMARY KEY (`idTipoDocumento`);

--
-- Indices de la tabla `TipoUsuario`
--
ALTER TABLE `TipoUsuario`
  ADD PRIMARY KEY (`idTipoUsuario`);

--
-- Indices de la tabla `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD PRIMARY KEY (`idUsuarios`,`fk_idPersonas`,`RolSistema_idRolSistema`),
  ADD KEY `fk_Usuarios_Personas1` (`fk_idPersonas`),
  ADD KEY `fk_Usuarios_RolSistema1` (`RolSistema_idRolSistema`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Asistencia`
--
ALTER TABLE `Asistencia`
  MODIFY `idAsistencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `Asistencia`
--
ALTER TABLE `Asistencia`
  ADD CONSTRAINT `fk_Asistencia_Personas1` FOREIGN KEY (`fk_idPersonas`) REFERENCES `Personas` (`idPersonas`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Personas`
--
ALTER TABLE `Personas`
  ADD CONSTRAINT `fk_Ciudad1` FOREIGN KEY (`fk_idCiudad`) REFERENCES `Ciudad` (`idCiudad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Genero1` FOREIGN KEY (`fk_idGenero`) REFERENCES `Genero` (`idGenero`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TipoDocumento` FOREIGN KEY (`fk_idTipoDocumento`) REFERENCES `TipoDocumento` (`idTipoDocumento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_TipoUsuario1` FOREIGN KEY (`fk_idTipoUsuario`) REFERENCES `TipoUsuario` (`idTipoUsuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD CONSTRAINT `fk_Usuarios_Personas1` FOREIGN KEY (`fk_idPersonas`) REFERENCES `Personas` (`idPersonas`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Usuarios_RolSistema1` FOREIGN KEY (`RolSistema_idRolSistema`) REFERENCES `RolSistema` (`idRolSistema`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
